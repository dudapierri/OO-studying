package br.com.calculos;

public interface Classificavel {
    int getClassificacao();

}
