package br.com.ooExcercises;

public class TestaValores {
    public static void main(String[] args) {
        Conta conta = new Conta(245,13);


        System.out.println(conta.getNumero());
        System.out.println(conta.getAgencia());

        Conta conta2 = new Conta(1,1);

    }
}
