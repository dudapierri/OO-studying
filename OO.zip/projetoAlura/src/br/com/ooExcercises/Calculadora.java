package br.com.ooExcercises;

public class Calculadora {
    double numero;

    double calculaDobro(){
        return this.numero*2;
    }
}
