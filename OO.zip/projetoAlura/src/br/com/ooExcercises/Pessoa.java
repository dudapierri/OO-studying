package br.com.ooExcercises;

public class Pessoa {
    void escreva (){
        System.out.println("Olá, mundo!");
    }
}
