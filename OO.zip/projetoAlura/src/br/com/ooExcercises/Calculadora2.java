package br.com.ooExcercises;

public class Calculadora2 {
    double calcula(double valor){
        return valor*2;
    }
}
