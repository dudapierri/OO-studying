package br.com.ooExcercises;

public class CriaConta {
    public static void main(String[] args) {
       // Conta primeiraConta = new Conta();
      //  Conta segundaConta = new Conta();

        //primeiraConta.saldo = 200;
        //segundaConta.saldo = 50;
       // System.out.println(primeiraConta.getSaldo());
       // primeiraConta.saldo += 100;
       // System.out.println(primeiraConta.getSaldo());
      //  System.out.println(primeiraConta.titular);
    }
}
